import React from 'react';
import "./Error.css";

const Error = () => {
  return (
    <div className="card notFoundCard">
    <img src="https://cdn.dribbble.com/users/4174206/screenshots/16831422/media/1b2ee350ad6421b644c363e7dcdcdf9f.jpg" className="card-img-top notFoundImage" alt="..." />
  </div>
  )
}

export default Error;